<?php

/**
 * The outside frame that holds all of the OpenEMR User Interface.
 *
 * @package   OpenEMR
 * @link      https://www.open-emr.org
 * @author    Rod Roark <rod@sunsetsystems.com>
 * @author    Brady Miller <brady.g.miller@gmail.com>
 * @author    Ranganath Pathak <pathak@scrs1.org>
 * @author    Michael A. Smith <michael@opencoreemr.com>
 * @copyright Copyright (c) 2018 Rod Roark <rod@sunsetsystems.com>
 * @copyright Copyright (c) 2018-2019 Brady Miller <brady.g.miller@gmail.com>
 * @copyright Copyright (c) 2019 Ranganath Pathak <pathak@scrs1.org>
 * @copyright Copyright (c) 2026 OpenCoreEMR Inc <https://opencoreemr.com/>
 * @license   https://github.com/openemr/openemr/blob/master/LICENSE GNU General Public License 3
 */

// Set $sessionAllowWrite to true to prevent session concurrency issues during authorization and app setup related code
$sessionAllowWrite = true;
require_once('../globals.php');

use OpenEMR\BC\ServiceContainer;
use OpenEMR\Common\Auth\AuthEvent;
use OpenEMR\Common\Auth\AuthUtils;
use OpenEMR\Common\Crypto\CryptoGenException;
use OpenEMR\Common\Crypto\KeyVersion;
use OpenEMR\Common\Crypto\PasswordBasedCrypto;
use OpenEMR\Common\Csrf\CsrfUtils;
use OpenEMR\Common\Logging\EventAuditLogger;
use OpenEMR\Common\Session\SessionTracker;
use OpenEMR\Common\Session\SessionWrapperFactory;
use OpenEMR\Common\Utils\RandomGenUtils;
use OpenEMR\Core\Header;
use OpenEMR\Core\OEGlobalsBag;
use OpenEMR\Services\FacilityService;
use OpenEMR\Services\ListService;

$session = SessionWrapperFactory::getInstance()->getActiveSession();

///////////////////////////////////////////////////////////////////////
// Functions to support MFA.
///////////////////////////////////////////////////////////////////////

function posted_to_hidden($name): void
{
    if (isset($_POST[$name])) {
        echo "<input type='hidden' name='" . attr($name) . "' value='" . attr($_POST[$name]) . "' />\r\n";
    }
}

function generate_html_start(): void
{
    ?>
    <html>
    <head>
    <?php Header::setupHeader(); ?>
    <title><?php echo xlt("MFA Authorization"); ?></title>
    <style>
    .alert-msg {
        font-size:100%;
        font-weight:700;
    }
    </style>
    <?php
}

function generate_html_u2f(): void
{
    global $appId;
    ?>
    <script src="<?php echo OEGlobalsBag::getInstance()->getWebRoot() ?>/library/js/u2f-api.js?v=<?php echo attr_url(OEGlobalsBag::getInstance()->getString('v_js_includes')); ?>"></script>
    <script>
        function doAuth() {
            var f = document.getElementById("u2fform");
            var requests = JSON.parse(f.form_requests.value);
            // The server's getAuthenticateData() repeats the same challenge in all requests.
            var challenge = requests[0].challenge;
            var registeredKeys = new Array();
            for (var i = 0; i < requests.length; ++i) {
                registeredKeys[i] = {"version": requests[i].version, "keyHandle": requests[i].keyHandle};
            }
            u2f.sign(
                <?php echo js_escape($appId); ?>,
                challenge,
                registeredKeys,
                function (data) {
                    if (data.errorCode && data.errorCode != 0) {
                        alert(<?php echo xlj("Key access failed with error"); ?> +' ' + data.errorCode);
                        return;
                    }
                    f.form_response.value = JSON.stringify(data);
                    f.submit();
                },
                60
            );
        }

    </script>
    <?php
}
function input_focus(): void
{
    ?>
    <script>
        $(function () {
                $('#totp').focus();
        });
    </script>

    <?php
}

function generate_html_top(): void
{
    echo '</head>';
    echo '<body>';
}

function generate_html_middle(): void
{
    posted_to_hidden('new_login_session_management');
    posted_to_hidden('languageChoice');
    posted_to_hidden('authUser');
    posted_to_hidden('clearPass');
}

function generate_html_end()
{
    // to be safe, remove clearPass from memory now (if it is not empty yet)
    if (!empty($_POST["clearPass"])) {
        if (function_exists('sodium_memzero')) {
            sodium_memzero($_POST["clearPass"]);
        } else {
            $_POST["clearPass"] = '';
        }
    }
    echo "</div></body></html>\n";
    SessionWrapperFactory::getInstance()->destroyCoreSession();
    return 0;
}

if (isset($_POST['new_login_session_management'])) {
///////////////////////////////////////////////////////////////////////
// Begin code to support U2F and APP Based TOTP logic.
///////////////////////////////////////////////////////////////////////
    $errormsg = '';
    $regs = [];          // for mapping device handles to their names
    $registrations = []; // the array of stored registration objects
    $res1 = sqlStatement(
        "SELECT a.name, a.method, a.var1 FROM login_mfa_registrations AS a " .
        "WHERE a.user_id = ? AND (a.method = 'TOTP' OR a.method = 'U2F') ORDER BY a.name",
        [$session->get('authUserID')]
    );

    $registrationAttempt = false;
    $isU2F = false;
    $isTOTP = false;
    while ($row1 = sqlFetchArray($res1)) {
        $registrationAttempt = true;
        if ($row1['method'] === 'U2F') {
            $isU2F = true;
            $regobj = json_decode((string) $row1['var1']);
            $regs[json_encode($regobj->keyHandle)] = $row1['name'];
            $registrations[] = $regobj;
        } else { // $row1['method'] == 'TOTP'
            $isTOTP = true;
        }
    }

    if ($registrationAttempt) {
        $requests = '';
        $errortype = '';
        if ($isU2F) {
            // There is at least one U2F key registered so we have to request or verify key data.
            // https is required, and with a proxy the server might not see it.
            $scheme = "https://"; // isset($_SERVER['HTTPS']) ? "https://" : "http://";
            $appId = $scheme . $_SERVER['HTTP_HOST'];
            $u2f = new u2flib_server\U2F($appId);
        }
        $userid = $session->get('authUserID');
        $form_response = empty($_POST['form_response']) ? '' : $_POST['form_response'];
        if ($form_response) {
            // TOTP METHOD enabled if TOTP is visible in post request
            if (isset($_POST['totp']) && trim((string) $_POST['totp']) != "" && $isTOTP) {
                $errormsg = false;

                $form_response = '';

                $res1 = sqlQuery(
                    "SELECT a.var1 FROM login_mfa_registrations AS a WHERE a.user_id = ? AND a.method = 'TOTP'",
                    [$session->get('authUserID')]
                );
                $registrationSecret = false;
                if (!empty($res1['var1'])) {
                    $registrationSecret = $res1['var1'];
                }

                // Decrypt the secret
                // First, try standard method that uses standard key
                $cryptoGen = ServiceContainer::getCrypto();
                try {
                    $secret = $cryptoGen->decryptFromDatabase(is_string($registrationSecret) ? $registrationSecret : null);
                } catch (CryptoGenException) {
                    $secret = null;
                }
                if (empty($secret)) {
                    // Second, try the password hash, which was setup during install and is temporary
                    $passwordResults = privQuery(
                        "SELECT password FROM users_secure WHERE username = ?",
                        [$_POST["authUser"]]
                    );
                    if (!empty($passwordResults["password"])) {
                        $passwordCrypto = new PasswordBasedCrypto(KeyVersion::CURRENT);
                        try {
                            $secret = $passwordCrypto->decrypt((string) $registrationSecret, (string) $passwordResults["password"]);
                        } catch (CryptoGenException) {
                            $secret = null;
                        }
                        if (!empty($secret)) {
                            error_log("Disregard the decryption failed authentication error reported above this line; it is not an error.");
                            // Re-encrypt with the more secure standard key
                            $secretEncrypt = $cryptoGen->encryptForDatabase($secret);
                            privStatement(
                                "UPDATE login_mfa_registrations SET var1 = ? where user_id = ? AND method = 'TOTP'",
                                [$secretEncrypt, $userid]
                            );
                        }
                    }
                }

                if (!empty($secret)) {
                    $googleAuth = new Totp($secret);
                    $form_response = $googleAuth->validateCode($_POST['totp']);
                }

                if ($form_response) {
                    // Keep track of when challenges were last answered correctly.
                    privStatement(
                        "UPDATE users_secure SET last_challenge_response = NOW() WHERE id = ?",
                        [$session->get('authUserID')]
                    );
                } else {
                    $mfaUsername = $session->get('authUser');
                    $mfaAuthGroup = $session->get('authProvider');
                    EventAuditLogger::getInstance()->logAuthFailure(
                        AuthEvent::mfa(),
                        is_string($mfaUsername) ? $mfaUsername : null,
                        is_string($mfaAuthGroup) ? $mfaAuthGroup : '',
                        'TOTP code incorrect'
                    );
                    $errormsg = xl("The code you entered was not valid");
                    $errortype = "TOTP";
                }
            } elseif ($isU2F) { // Otherwise use U2F METHOD
                // We have key data, check if it matches what was registered.
                $tmprow = sqlQuery("SELECT login_work_area FROM users_secure WHERE id = ?", [$userid]);
                try {
                    $registration = $u2f->doAuthenticate(
                        json_decode((string) $tmprow['login_work_area']), // these are the original challenge requests
                        $registrations,
                        json_decode((string) $_POST['form_response'])
                    );
                    // Stored registration data needs to be updated because the usage count has changed.
                    // We have to use the matching registered key.
                    $strhandle = json_encode($registration->keyHandle);
                    if (isset($regs[$strhandle])) {
                        sqlStatement(
                            "UPDATE login_mfa_registrations SET `var1` = ? WHERE " .
                            "`user_id` = ? AND `method` = 'U2F' AND `name` = ?",
                            [json_encode($registration), $userid, $regs[$strhandle]]
                        );
                    } else {
                        error_log("Unexpected keyHandle returned from doAuthenticate(): '" . errorLogEscape($strhandle) . "'");
                    }
                    // Keep track of when challenges were last answered correctly.
                    sqlStatement(
                        "UPDATE users_secure SET last_challenge_response = NOW() WHERE id = ?",
                        [$session->get('authUserID')]
                    );
                } catch (\u2flib_server\Error $e) {
                    // Authentication failed so we will build the U2F form again.
                    $form_response = '';
                    $mfaUsername = $session->get('authUser');
                    $mfaAuthGroup = $session->get('authProvider');
                    EventAuditLogger::getInstance()->logAuthFailure(
                        AuthEvent::mfa(),
                        is_string($mfaUsername) ? $mfaUsername : null,
                        is_string($mfaAuthGroup) ? $mfaAuthGroup : '',
                        'U2F authentication error: ' . $e->getMessage()
                    );
                    $errormsg = xl('U2F Key Authentication error') . ": " . $e->getMessage();
                    $errortype = "U2F";
                }
            } else {
                // do nothing
                $form_response = '';
            }
        }
        if (!$form_response) {
            generate_html_start();
            if ($isU2F) {
                generate_html_u2f();
            }
            if ($isTOTP) {
                input_focus();
            }
            generate_html_top();
            if ($isTOTP) {
                echo '<div class="container">';
                echo '<div class="row">';
                echo '    <div class="col-sm-12">';
                echo '        <h2>' . xlt('TOTP Verification') . '</h2>';
                echo '    </div>';
                echo '</div>';
                if ($errormsg && $errortype == "TOTP") {
                    echo '<div class="row"><div class="col-sm-12"><div class="alert alert-danger alert-msg">' . text($errormsg) . '</div></div></div>';
                }

                echo '<div class="row">';
                echo '  <div class="col-sm-12">';
                echo '      <form method="post" action="main_screen.php?auth=login&site=' . attr_url($_GET['site']) . '" target="_top" name="challenge_form" id="challenge_form">';
                echo '              <fieldset>';
                echo '                  <legend>' . xlt('Provide TOTP code') . '</legend>';
                echo '                  <div class="form-group">';
                echo '                      <div class="col-sm-6 offset-sm-3">';
                echo '                          <label for="totp">' . xlt('Enter the code from your authentication application on your device') . ':</label>';
                echo '                          <input type="text" name="totp" class="form-control input-lg" id="totp" maxlength="12" required>';
                echo '                          <input type="hidden" name="form_response" value="true" />';
                generate_html_middle();
                echo '                  </div>';
                echo '              </fieldset>';
                echo '                  <div class="form-group clearfix">';
                echo '                      <div class="col-sm-12 text-left position-override">';
                echo '                          <button type="submit" class="btn btn-secondary btn-save">' . xlt('Authenticate TOTP') . '</button>';
                echo '                  </div>';
                echo '              </div>';
                echo '          </div>';
                echo '      </form>';
                echo '  </div>';
                echo '</div>';
            }
            if ($isU2F) {
                // There is no key data yet or authentication failed, so we need to solicit it.
                $requests = json_encode($u2f->getAuthenticateData($registrations));
                // Persist the challenge also in the database because the browser is untrusted.
                sqlStatement(
                    "UPDATE users_secure SET login_work_area = ? WHERE id = ?",
                    [$requests, $userid]
                );

                echo '<div class="container">';
                echo '<div class="row">';
                echo '    <div class="col-sm-12">';
                echo '        <h2>' . xlt('U2F Key Verification') . '</h2>';
                echo '    </div>';
                echo '</div>';
                if ($errormsg && $errortype == "U2F") {
                    echo '<div class="row"><div class="col-sm-12"><div class="alert alert-danger  alert-msg">' . text($errormsg) . '</div></div></div>';
                }
                echo '<div class="row">';
                echo '  <div class="col-sm-12">';
                echo '          <form method="post" name="u2fform" id="u2fform" action="main_screen.php?auth=login&site=' . attr_url($_GET['site']) . '" target="_top">';
                echo '              <fieldset>';
                echo '                  <legend>' . xlt('Insert U2F Key') . '</legend>';
                echo '                  <div class="form-group">';
                echo '                      <div class="col-sm-6 offset-sm-3">';
                echo '                          <ul>';
                echo '                              <li>' . xlt('Insert your key into a USB port and click the Authenticate button below.') . '</li>';
                echo '                              <li>' . xlt('Then press the flashing button on your key within 1 minute.') . '</li>';
                echo '                          </ul>';
                echo '                  </div>';
                echo '              </fieldset>';
                echo '                  <div class="form-group clearfix">';
                echo '                      <div class="col-sm-12 text-left position-override">';
                echo '                          <button type="button"  id="authutf" class="btn btn-secondary btn-save" onclick="doAuth()">' . xlt('Authenticate U2F') . '</button>';
                echo '                          <input type="hidden" name="form_requests" value="' . attr($requests) . '" />';
                echo '                          <input type="hidden" name="form_response" value="" />';
                generate_html_middle();
                echo '                      </div>';
                echo '                  </div>';
                echo '          </form>';
                echo '  </div>';
                echo '</div>';
            }
            exit(generate_html_end());
        }
    }
    ///////////////////////////////////////////////////////////////////////
    // End of U2F and APP Based TOTP logic.
    ///////////////////////////////////////////////////////////////////////


    // Creates a new session id when load this outer frame
    // (allows creations of separate OpenEMR frames to view patients concurrently
    //  on different browser frame/windows)
    // This session id is used below in the restoreSession.php include to create a
    // session cookie for this specific OpenEMR instance that is then maintained
    // within the OpenEMR instance by calling top.restoreSession() whenever
    // refreshing or starting a new script.

    // This is a new login, so create a new session id and remove the old session
    $session->migrate(true);
    // Also need to delete clearPass from memory
    if (function_exists('sodium_memzero')) {
        sodium_memzero($_POST["clearPass"]);
    } else {
        $_POST["clearPass"] = '';
    }
    // Set up the csrf private_key
    //  Note this key always remains private and never leaves server session. It is used to create
    //  the csrf tokens.
    //  Generated only on the new-login path. Rotating it on every main_screen.php load
    //  invalidates CSRF tokens already embedded in long-lived iframes (e.g. dated_reminders,
    //  which polls every 60s with the token captured at render time).
    CsrfUtils::setupCsrfKey($session);
} else {
    CsrfUtils::checkCsrfInput(INPUT_POST, dieOnFail: true);
    $session->migrate(false);
}
// Set up the session uuid. This will be used for mapping session setting to database.
//  At this time only used for lastupdate tracking
SessionTracker::setupSessionDatabaseTracker();

$session->set("encounter", '');

if (OEGlobalsBag::getInstance()->getBoolean('login_into_facility')) {
    $facility_id = $_POST['facility'];
    if ($facility_id === 'user_default') {
        //get the default facility of login user from users table
        $facilityService = new FacilityService();
        $facility = $facilityService->getFacilityForUser($session->get('authUserID'));
        $facility_id = $facility['id'];
    }
    $session->set('facilityId', $facility_id);
    if (OEGlobalsBag::getInstance()->getBoolean('set_facility_cookie')) {
        // set cookie with facility for the calendar screens
        setcookie("pc_facility", (string) $session->get('facilityId'), ['expires' => time() + (3600 * 365), 'path' => OEGlobalsBag::getInstance()->getWebRoot()]);
    }
}

// Fetch the password expiration date (note LDAP skips this)
$is_expired = false;
if ((!AuthUtils::useActiveDirectory()) && (OEGlobalsBag::getInstance()->getInt('password_expiration_days') != 0) && (check_integer(OEGlobalsBag::getInstance()->getInt('password_expiration_days')))) {
    $result = privQuery("select `last_update_password` from `users_secure` where `id` = ?", [$session->get('authUserID')]);
    $current_date = date('Y-m-d');
    if (!empty($result['last_update_password'])) {
        $pwd_last_update = $result['last_update_password'];
    } else {
        error_log("OpenEMR ERROR: there is a problem with recording of last_update_password entry in users_secure table");
        $pwd_last_update = $current_date;
    }

    // Display the password expiration message (will show during the grace time)
    $pwd_alert_date = date('Y-m-d', strtotime($pwd_last_update . '+' . OEGlobalsBag::getInstance()->getInt('password_expiration_days') . ' days'));

    if (empty(strtotime($pwd_alert_date))) {
        error_log("OpenEMR ERROR: there is a problem when trying to check if user's password is expired");
    } elseif (strtotime($current_date) >= strtotime($pwd_alert_date)) {
        $is_expired = true;
    }
}

$listSvc = new ListService();
$_tabs = $listSvc->getOptionsByListName('default_open_tabs', ['activity' => 1]);

if ($is_expired) {
    //display the php file containing the password expiration message.
    array_unshift($_tabs, [
        'notes' => "interface/main/pwd_expires_alert.php?csrf_token_form=" . CsrfUtils::collectCsrfToken(session: $session),
        'id' => "adm",
        "label" => xl("Password Reset"),
    ]);
} elseif (!empty($_POST['patientID'])) {
    // Patient is open, so add this to the list of tabs, at the end
    $patientID = (int) $_POST['patientID'];
    $_notes = "../patient_file/summary/demographics.php?set_pid=" . attr_url($patientID);
    if (!empty($_POST['encounterID'])) {
        $encounterID = (int) $_POST['encounterID'];
        $_notes = $_notes . "&set_encounterid=" . attr_url($encounterID);
    }
    $_tabs[] = [
        'notes' => $_notes,
        'id' => "pat",
        'label' => xl("Dashboard"),
    ];
} elseif (isset($_GET['mode']) && $_GET['mode'] == "loadcalendar") {
    // Load the calendar, at the end
    $_notes = "calendar/index.php?pid=" . attr_url($_GET['pid']);
    $_notes = (isset($_GET['date'])) ? $_notes . "&date=" . attr_url($_GET['date']) : $_notes;
    $_tabs[] = [
        'notes' => $_notes,
        'id' => "cal",
        "label" => xl("Calendar"),
    ];
}

// Will set Session variables to communicate settings to tab layout
$session->set('default_open_tabs', $_tabs);
// mdsupport - Apps processing invoked for valid app selections from list
if ((isset($_POST['appChoice'])) && ($_POST['appChoice'] !== '*OpenEMR')) {
    $session->set('app1', $_POST['appChoice']);
}

// Pass a unique token, so main.php script can not be run on its own
$tokenMainPhp = RandomGenUtils::createUniqueToken();
$session->set('token_main_php', $tokenMainPhp);
header(
    'Location: ' . OEGlobalsBag::getInstance()->getWebRoot() .
    "/interface/main/tabs/main.php?token_main=" . urlencode($tokenMainPhp) .
    "&site=" . urlencode((string) $session->get('site_id'))
);
exit();
?>
